//package com.iomt.android.ui.home;
//
//import android.arch.lifecycle.ViewModelProviders;
//import android.bluetooth.BluetoothAdapter;
//import android.bluetooth.BluetoothDevice;
//import android.bluetooth.BluetoothManager;
//import android.content.Context;
//import android.content.Intent;
//import android.os.Bundle;
//import android.os.Handler;
//import android.support.annotation.NonNull;
//import android.support.annotation.Nullable;
//import android.support.v4.app.Fragment;
//import android.support.v7.app.AppCompatActivity;
//import android.support.v7.widget.LinearLayoutManager;
//import android.support.v7.widget.RecyclerView;
//import android.support.v7.widget.Toolbar;
//import android.util.Log;
//import android.view.LayoutInflater;
//import android.view.Menu;
//import android.view.MenuInflater;
//import android.view.MenuItem;
//import android.view.View;
//
//import com.iomt.android.DeviceAdapter;
//import com.iomt.android.DeviceCell;
//import com.iomt.android.R;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Objects;
//
//
//public class HomeFragment extends Fragment implements DeviceAdapter.OnClickListener {
//
//    private HomeViewModel homeViewModel;
//    private RecyclerView.Adapter myAdapter;
//    private Handler uiHandler;
//    private BluetoothAdapter bluetoothAdapter;
//    private MenuItem menuItem;
//    private List<DeviceCell> deviceCells = new ArrayList<>();
//    private LayoutInflater inflater;
//    private RecyclerView recyclerView;
//    private Context context;
//
////    public View onCreateView(@NonNull LayoutInflater inflater,
////                             ViewGroup container, Bundle savedInstanceState) {
////        homeViewModel =
////                ViewModelProviders.of(this).get(HomeViewModel.class);
////
////        return inflater.inflate(R.layout.fragment_home, container, false);
////    }
//
//    @Override
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setHasOptionsMenu(true);
//        uiHandler = new Handler();
//        bluetoothAdapter = ((BluetoothManager) getActivity().getSystemService(Context.BLUETOOTH_SERVICE)).getAdapter();
//        context = requireContext();
//        inflater = LayoutInflater.from(context);
//    }
//
////    @Override
////    public View onCreateView(@NonNull LayoutInflater inflater,
////                             ViewGroup container, Bundle savedInstanceState) {
////
////        View view = inflater.inflate(R.layout.fragment_home, container, false);
////        Toolbar toolbar = (Toolbar) view.findViewById(R.id.toolbar_list);
////        ((AppCompatActivity) Objects.requireNonNull(getActivity())).setSupportActionBar(toolbar);
////
////        homeViewModel = ViewModelProviders.of(this).get(HomeViewModel.class);
////
////        recyclerView = Objects.requireNonNull(view).findViewById(R.id.my_recycler_view);
////        recyclerView.setHasFixedSize(true);
////        RecyclerView.LayoutManager _layoutManager = new LinearLayoutManager(context, RecyclerView.VERTICAL, false);
////        recyclerView.setLayoutManager(_layoutManager);
////        myAdapter = new DeviceAdapter(inflater, deviceCells, this);
////        recyclerView.setAdapter(myAdapter);
////        return view;
////    }
//    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
//        recyclerView = view.findViewById(R.id.my_recycler_view);
//        recyclerView.setHasFixedSize(true);
//
//        Toolbar toolbar = (Toolbar) view.findViewById(R.id.toolbar_list);
//        ((AppCompatActivity) Objects.requireNonNull(getActivity())).setSupportActionBar(toolbar);
//
//        RecyclerView.LayoutManager _layoutManager = new LinearLayoutManager(context, RecyclerView.VERTICAL, false);
//        recyclerView.setLayoutManager(_layoutManager);
//        homeViewModel = ViewModelProviders.of(this).get(HomeViewModel.class);
//
//        //myAdapter = recyclerView.getAdapter();
//
//
//        myAdapter = new DeviceAdapter(inflater, deviceCells, this);
//        recyclerView.setAdapter(myAdapter);
//    }
//
//    private BluetoothAdapter.LeScanCallback mLeScanCallback =
//            new BluetoothAdapter.LeScanCallback() {
//                @Override
//                public void onLeScan(final BluetoothDevice device, int rssi,
//                                     byte[] scanRecord) {
//                    getActivity().runOnUiThread(new Runnable() {
//                        @Override
//                        public void run() {
//                            if (device.getName() != null && device.getName().startsWith("HX")) {
//                                Log.d("FOUND DEVICE", device.getName());
//                                boolean found = false;
//                                for (DeviceCell d : deviceCells) {
//                                    if (d.getDevice().getName().equals(device.getName())) {
//                                        found = true;
//                                        break;
//                                    }
//                                }
//
//                                if (!found) {
//                                    Log.d("ADD DEVICE", device.getName());
//                                    deviceCells.add(new DeviceCell(device));
//                                    myAdapter.notifyDataSetChanged();
//                                }
//                            }
//                        }
//                    });
//                }
//            };
//
//
//    @Override
//    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
//        //MenuInflater inflater = getMenuInflater();
//        inflater.inflate(R.menu.menu_device_list, menu);
//        super.onCreateOptionsMenu(menu,inflater);
//        menuItem = menu.findItem(R.id.scan);
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        switch (item.getItemId()) {
//            case R.id.scan:
//                if (myAdapter == null) {
//                    myAdapter = new DeviceAdapter(inflater, deviceCells, this);
//                    if (recyclerView != null && recyclerView.getAdapter() != myAdapter)
//                        recyclerView.setAdapter(myAdapter);
//                }
//                scanLeDevice();
//                return true;
//            default:
//                return super.onOptionsItemSelected(item);
//        }
//    }
//
//    // Stops scanning after 10 seconds.
//    private static final long SCAN_PERIOD = 10000;
//
//    // Scan for BLE devices
//    private void scanLeDevice() {
//        // Clear devices
//        deviceCells.clear();
//        //_devices.clear();
//
//        // reload table
//        myAdapter.notifyDataSetChanged();
//        //stopScan();
//
//        // Stops scanning after a pre-defined scan period.
//        uiHandler.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                stopScan();
//            }
//        }, SCAN_PERIOD);
//
//        menuItem.setEnabled(false);
//
//        // scan
//        bluetoothAdapter.startLeScan(mLeScanCallback);
//    }
//
//    public void stopScan() {
//        menuItem.setEnabled(true);
//        bluetoothAdapter.stopLeScan(mLeScanCallback);
//    }
//
//    @Override
//    public void onClickItem(DeviceCell deviceCell, BluetoothDevice device) {
//        stopScan();
//        // Show Device Detail
//        Intent intent = new Intent(getActivity(), HomeFragment.class);
//        intent.putExtra("Device", device);
//        startActivity(intent);
//    }
//}


package com.iomt.android.ui.home;

import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import androidx.navigation.ui.AppBarConfiguration;

import com.iomt.android.DeviceActivity;
import com.iomt.android.DeviceAdapter;
import com.iomt.android.DeviceCell;
import com.iomt.android.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Displays list of Hexoskin Devices
 */
public class HomeFragment extends Fragment implements DeviceAdapter.OnClickListener {
    private BluetoothAdapter bluetoothAdapter;
    private Handler uiHandler;

    private MenuItem menuItem;

    private List<DeviceCell> deviceCells = new ArrayList<>();
    private static final int PERMISSION_REQUEST_COARSE_LOCATION = 1;
    private DeviceAdapter myAdapter;
    private AppBarConfiguration mAppBarConfiguration;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setHasOptionsMenu(true);
        bluetoothAdapter = ((BluetoothManager)getActivity().getSystemService(Context.BLUETOOTH_SERVICE)).getAdapter();
        uiHandler = new Handler();



        //LayoutInflater inflater = LayoutInflater.from(getActivity().getApplicationContext());

        //if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        //    requestPermissions(new String[] { Manifest.permission.ACCESS_COARSE_LOCATION }, PERMISSION_REQUEST_COARSE_LOCATION);
        //}
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_home, container, false);
        setHasOptionsMenu(true);
        Toolbar toolbar = (Toolbar) view.findViewById(R.id.toolbar_list);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Devices");

        RecyclerView recyclerView = view.findViewById(R.id.my_recycler_view);
        recyclerView.setHasFixedSize(true);

        RecyclerView.LayoutManager _layoutManager = new LinearLayoutManager(requireContext(), RecyclerView.VERTICAL, false);
        recyclerView.setLayoutManager(_layoutManager);
        myAdapter = new DeviceAdapter(inflater, deviceCells, this);
        recyclerView.setAdapter(myAdapter);
        return view;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[],
                                           int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_COARSE_LOCATION: {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    menuItem.setEnabled(true);
                } else {
                    final AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
                    builder.setTitle("Location not granted");
                    builder.setMessage("Since location access has not been granted, this app will not be able to discover nearby bluetooth devices.");
                    builder.setPositiveButton(android.R.string.ok, null);
                    builder.show();

                    menuItem.setEnabled(false);
                }
                return;
            }
        }
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        //MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_device_list, menu);
        menuItem = menu.findItem(R.id.scan);
        //return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.scan:
                scanLeDevice();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private BluetoothAdapter.LeScanCallback mLeScanCallback =
            new BluetoothAdapter.LeScanCallback() {
                @Override
                public void onLeScan(final BluetoothDevice device, int rssi,
                                     byte[] scanRecord) {
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (device.getName() != null && device.getName().startsWith("HX")) {
                                boolean found = false;
                                for (DeviceCell d : deviceCells) {
                                    if (d.getDevice().getName().equals(device.getName())) {
                                        found = true;
                                        break;
                                    }
                                }

                                if(!found) {
                                    deviceCells.add(new DeviceCell(device));
                                    myAdapter.notifyDataSetChanged();
                                }
                            }
                        }
                    });
                }
            };

    // Stops scanning after 10 seconds.
    private static final long SCAN_PERIOD = 10000;

    // Scan for BLE devices
    private void scanLeDevice() {
        // Clear devices
        deviceCells.clear();
        //_devices.clear();

        // reload table
        myAdapter.notifyDataSetChanged();
        //stopScan();

        // Stops scanning after a pre-defined scan period.
        uiHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                stopScan();
            }
        }, SCAN_PERIOD);

        menuItem.setEnabled(false);

        // scan
        bluetoothAdapter.startLeScan(mLeScanCallback);
    }

    public void stopScan() {
        menuItem.setEnabled(true);
        bluetoothAdapter.stopLeScan(mLeScanCallback);
    }

    @Override
    public void onClickItem(DeviceCell deviceCell, BluetoothDevice device) {
        stopScan();
        // Show Device Detail
        Intent intent = new Intent(getActivity(), DeviceActivity.class);
        intent.putExtra("Device", device);
        startActivity(intent);
    }
}
