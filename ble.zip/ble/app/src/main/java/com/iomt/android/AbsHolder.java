package com.iomt.android;

import android.support.v7.widget.RecyclerView;
import android.view.View;

public abstract class AbsHolder extends RecyclerView.ViewHolder {
    public AbsHolder(final View itemView) {
        super(itemView);
    }

    public abstract void bind(final AbsCell absCell);
}
