package com.iomt.android;

public abstract class AbsCell {

    AbsCell(){}
}
